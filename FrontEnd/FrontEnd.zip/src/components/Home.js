import React from "react";
import ReactPlayer from "react-player";
import { Box, Button, Stack, Typography } from "@mui/material";
import classes from "./Header.module.css";
import ArrowForwardIcon from "@mui/icons-material/ArrowForward";
import { NavLink } from "react-router-dom";
import { useState } from "react";
import welcome_video from "../assets/welcome-video_p3wXtgtf.mp4";

const Home = () => {
  const uploadButtonHandler = (event) => {
    const file = event.target.files[0];
    const url = URL.createObjectURL(file);
    setEntredUrl(url);
  };

  const [enteredUrl, setEntredUrl] = useState(welcome_video);

  return (
    <Box display="flex" flexDirection="row">
      <Box
        sx={{
          backgroundColor: "#1f1d1d",
          height: "91vh",
          width: "75vw",
          display: "flex",
          flexDirection: "column",
          alignItems: "center",
          justifyContent: "center",
          gap: 4,
        }}
      >
        <ReactPlayer
          url={enteredUrl}
          width="60vw"
          height="60vh"
          playing
          controls
        ></ReactPlayer>
        <Button
          variant="contained"
          component="label"
          xs={{}}
          onChange={uploadButtonHandler}
        >
          Upload
          <input hidden accept="video/*" multiple type="file" />
        </Button>
      </Box>
      <Stack
        direction="column"
        bgcolor="#1f1d1d"
        justifyContent="center"
        alignItems="center"
        sx={{
          width: "25vw",
          height: "91vh",
        }}
      >
        <Typography variant="h5" color="#fff">
          Classified <span className={classes.span}>C</span>lass :
        </Typography>
        <Typography variant="h5" color=" rgb(250, 35, 35)">
          Cricket
        </Typography>
        <Box
          sx={{
            mt: "25px",
          }}
        >
          <NavLink to="recomandations/someid">
            <Button
              variant="contained"
              endIcon={<ArrowForwardIcon></ArrowForwardIcon>}
            >
              Get Recomendations
            </Button>
          </NavLink>
        </Box>
      </Stack>
    </Box>
  );
};

export default Home;
